target/release/ferrum serve /workspace/hf-cache/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a --backend cuda --host 127.0.0.1 --port 18107 --profile-detail off 
